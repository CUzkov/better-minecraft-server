////////////////////////
/// Made by Team AOF ///
////////////////////////

onEvent('recipes', (event) => {

  // Salt Dust
  event.shaped("2x bewitchment:salt", [["modern_industrialization:salt_dust"],["modern_industrialization:salt_dust"]]);
 
});
