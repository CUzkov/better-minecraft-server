

////////////////////////
/// Made by Team AOF ///
////////////////////////


onEvent('recipes', (event) => {

  // Big Torch
  event.shaped('kibe:big_torch', [
    ['bewitchment:golden_candelabra',             'bewitchment:golden_candelabra', 'bewitchment:golden_candelabra'],
    ['modern_industrialization:diamond_plate',    '#minecraft:logs',                'modern_industrialization:diamond_plate'],
    ['modern_industrialization:gold_large_plate', '#minecraft:logs',                'modern_industrialization:gold_large_plate'],
  ]);

});
